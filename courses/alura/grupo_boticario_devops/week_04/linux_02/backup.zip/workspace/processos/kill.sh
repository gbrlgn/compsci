kill pid

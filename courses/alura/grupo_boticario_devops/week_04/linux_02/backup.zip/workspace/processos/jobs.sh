jobs # (mostra processos parados)

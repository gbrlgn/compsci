ps -ef | grep nomedoprocesso

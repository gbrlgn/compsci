pstree # (mostra árvore de processos)

bg numerodoprocesso # faz rodar em segundo plano
fg numerodoprocesso # traz o processo ao primeiro plano
nomedoprograma & # abre o programa em segundo plano

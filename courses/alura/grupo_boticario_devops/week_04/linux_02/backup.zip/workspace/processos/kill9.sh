kill -9 pid

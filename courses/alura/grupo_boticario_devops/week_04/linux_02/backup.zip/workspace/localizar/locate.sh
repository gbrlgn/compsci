locate firefox # busca os arquivos com o nome firefox no
# banco de dados de arquivos atual

sudo updatedb # atualiza o banco de dados

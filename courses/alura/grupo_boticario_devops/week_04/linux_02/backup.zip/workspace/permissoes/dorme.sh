echo Vou dormir
sleep 5
echo Já dormi

chmod +x dorme.sh # faz com que dorme.sh seja executável

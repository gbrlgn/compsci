chmod o-rx arquivooupasta # remove r e x de todos os usuários
# menos do dono. O o vem de others. Para o próprio usuário
# seria u e para o grupo seria g.

ps -e | wc -l # conta o número de processos.

wc -w *.txt | grep total # wc com a opção -w conta todas as
# palavras de um arquivo, o grep retornará o total. -c conta
# os caracteres e -l as linhas.
